#!/bin/bash

# Script to download the entire project for GitHub upload or deployment

echo "Preparing project for download..."

# Create a zip folder with all necessary files
mkdir -p ./stylehub-ecommerce
cp -r client server shared .gitignore .env.example README.md DEPLOYMENT.md package.json package-lock.json Procfile drizzle.config.ts tsconfig.json vite.config.ts ./stylehub-ecommerce/

# Create zip file
zip -r stylehub-ecommerce.zip ./stylehub-ecommerce

# Clean up
rm -rf ./stylehub-ecommerce

echo "Project has been packaged as 'stylehub-ecommerce.zip'"
echo "You can download this file and upload it to your GitHub repository"
echo "See DEPLOYMENT.md for detailed deployment instructions"