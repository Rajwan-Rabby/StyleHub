import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertProductSchema, insertOrderSchema, insertOrderItemSchema } from "@shared/schema";
import { z } from "zod";
import Stripe from "stripe";

// Initialize Stripe with the secret key
if (!process.env.STRIPE_SECRET_KEY) {
  throw new Error('Missing required Stripe secret: STRIPE_SECRET_KEY');
}

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY);

export async function registerRoutes(app: Express): Promise<Server> {
  // Seed products if none exist (only in development)
  app.get('/api/seed', async (req, res) => {
    try {
      const allProducts = await storage.getProducts();
      if (allProducts.length === 0) {
        // Import mock products data
        const { getProducts } = await import('../client/src/data/products');
        const products = await getProducts();
        
        // Insert each product into the database
        for (const product of products) {
          await storage.createProduct({
            name: product.name,
            description: product.description,
            price: product.price.toString(),
            salePrice: product.salePrice ? product.salePrice.toString() : null,
            imageUrl: product.imageUrl,
            category: product.category,
            subcategory: product.subcategory || null,
            rating: product.rating ? product.rating.toString() : null,
            reviewCount: product.reviewCount || null,
            stockCount: product.stockCount,
            isNew: product.isNew,
            isFeatured: product.isFeatured,
            isSale: product.isSale,
            colors: product.colors,
            sizes: product.sizes
          });
        }
        res.json({ message: 'Database seeded successfully', count: products.length });
      } else {
        res.json({ message: 'Database already has products', count: allProducts.length });
      }
    } catch (error) {
      console.error('Seeding error:', error);
      res.status(500).json({ message: 'Failed to seed database' });
    }
  });

  // API Routes
  // Get all products
  app.get('/api/products', async (req, res) => {
    try {
      const products = await storage.getProducts();
      res.json(products);
    } catch (error) {
      console.error('Error fetching products:', error);
      res.status(500).json({ message: 'Failed to fetch products' });
    }
  });

  // Special filter endpoints need to come before /:id
  // Get featured products
  app.get('/api/products/featured', async (req, res) => {
    try {
      const products = await storage.getFeaturedProducts();
      res.json(products);
    } catch (error) {
      console.error('Error fetching featured products:', error);
      res.status(500).json({ message: 'Failed to fetch featured products' });
    }
  });

  // Get new arrivals
  app.get('/api/products/new-arrivals', async (req, res) => {
    try {
      const products = await storage.getNewArrivals();
      res.json(products);
    } catch (error) {
      console.error('Error fetching new arrivals:', error);
      res.status(500).json({ message: 'Failed to fetch new arrivals' });
    }
  });

  // Get sale products
  app.get('/api/products/sale', async (req, res) => {
    try {
      const products = await storage.getSaleProducts();
      res.json(products);
    } catch (error) {
      console.error('Error fetching sale products:', error);
      res.status(500).json({ message: 'Failed to fetch sale products' });
    }
  });

  // Get products by category
  app.get('/api/products/category/:category', async (req, res) => {
    try {
      const category = req.params.category;
      const products = await storage.getProductsByCategory(category);
      res.json(products);
    } catch (error) {
      console.error('Error fetching products by category:', error);
      res.status(500).json({ message: 'Failed to fetch products by category' });
    }
  });

  // Search products
  app.get('/api/products/search/:query', async (req, res) => {
    try {
      const query = req.params.query;
      const products = await storage.searchProducts(query);
      res.json(products);
    } catch (error) {
      console.error('Error searching products:', error);
      res.status(500).json({ message: 'Failed to search products' });
    }
  });
  
  // Get a single product - this should come after all the special /api/products/... routes
  app.get('/api/products/:id', async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const product = await storage.getProductById(id);
      if (!product) {
        return res.status(404).json({ message: 'Product not found' });
      }
      res.json(product);
    } catch (error) {
      console.error('Error fetching product:', error);
      res.status(500).json({ message: 'Failed to fetch product' });
    }
  });

  // Create a new product
  app.post('/api/products', async (req, res) => {
    try {
      const productData = insertProductSchema.parse(req.body);
      const product = await storage.createProduct(productData);
      res.status(201).json(product);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: 'Invalid product data', errors: error.errors });
      } else {
        console.error('Error creating product:', error);
        res.status(500).json({ message: 'Failed to create product' });
      }
    }
  });

  // Create an order (checkout)
  app.post('/api/orders', async (req, res) => {
    try {
      const orderData = insertOrderSchema.parse(req.body);
      const order = await storage.createOrder(orderData);
      
      // Add order items
      if (req.body.items && Array.isArray(req.body.items)) {
        for (const item of req.body.items) {
          const orderItemData = insertOrderItemSchema.parse({
            ...item,
            orderId: order.id
          });
          await storage.addOrderItem(orderItemData);
        }
      }
      
      res.status(201).json({ message: 'Order created successfully', order });
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: 'Invalid order data', errors: error.errors });
      } else {
        console.error('Error creating order:', error);
        res.status(500).json({ message: 'Failed to create order' });
      }
    }
  });

  // Get user orders
  app.get('/api/orders/user/:userId', async (req, res) => {
    try {
      const userId = parseInt(req.params.userId);
      const orders = await storage.getUserOrders(userId);
      res.json(orders);
    } catch (error) {
      console.error('Error fetching user orders:', error);
      res.status(500).json({ message: 'Failed to fetch user orders' });
    }
  });

  // Get order details with items
  app.get('/api/orders/:id', async (req, res) => {
    try {
      const orderId = parseInt(req.params.id);
      const order = await storage.getOrderById(orderId);
      
      if (!order) {
        return res.status(404).json({ message: 'Order not found' });
      }
      
      const orderItems = await storage.getOrderItems(orderId);
      res.json({ order, items: orderItems });
    } catch (error) {
      console.error('Error fetching order details:', error);
      res.status(500).json({ message: 'Failed to fetch order details' });
    }
  });

  // Stripe payment endpoint - create a payment intent
  app.post('/api/create-payment-intent', async (req, res) => {
    try {
      const { amount } = req.body;
      
      // Validate amount
      if (!amount || typeof amount !== 'number' || amount <= 0) {
        return res.status(400).json({ message: 'Invalid amount' });
      }
      
      // Create a PaymentIntent with the order amount and currency
      const paymentIntent = await stripe.paymentIntents.create({
        amount: Math.round(amount * 100), // Convert dollars to cents
        currency: 'usd',
        automatic_payment_methods: {
          enabled: true,
        },
      });
      
      // Send the client secret to the client
      res.json({
        clientSecret: paymentIntent.client_secret,
      });
    } catch (error) {
      console.error('Error creating payment intent:', error);
      res.status(500).json({ message: 'Failed to create payment intent' });
    }
  });

  // Webhook endpoint to handle Stripe events (payment confirmations, etc.)
  app.post('/api/webhook', async (req, res) => {
    const sig = req.headers['stripe-signature'];
    
    // In production, you should verify the webhook signature
    // using the stripe.webhooks.constructEvent method and a webhook secret
    
    try {
      // Log the webhook event
      console.log('Received Stripe webhook event');
      
      // You can process different types of events here
      // e.g., payment_intent.succeeded, payment_intent.payment_failed
      
      res.json({ received: true });
    } catch (err) {
      const error = err as Error;
      console.error('Webhook error:', error);
      res.status(400).send(`Webhook Error: ${error.message}`);
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
