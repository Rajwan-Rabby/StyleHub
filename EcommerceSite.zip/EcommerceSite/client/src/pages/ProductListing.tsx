import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { getProducts } from "@/data/products";
import { Product, FilterOptions, SortOption } from "@/lib/types";
import ProductCard from "@/components/ProductCard";
import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { Checkbox } from "@/components/ui/checkbox";
import { Slider } from "@/components/ui/slider";
import { Separator } from "@/components/ui/separator";
import { Star, SlidersHorizontal, X } from "lucide-react";

const sortOptions: SortOption[] = [
  { id: "newest", name: "Newest" },
  { id: "price-low", name: "Price: Low to High" },
  { id: "price-high", name: "Price: High to Low" },
  { id: "rating", name: "Customer Rating" },
];

export default function ProductListing() {
  const [location] = useLocation();
  const urlParams = new URLSearchParams(location.split('?')[1]);
  const categoryFromUrl = urlParams.get('category');

  const [products, setProducts] = useState<Product[]>([]);
  const [filteredProducts, setFilteredProducts] = useState<Product[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [showFilters, setShowFilters] = useState(false);
  
  const [sortBy, setSortBy] = useState("newest");
  const [filters, setFilters] = useState<FilterOptions>({
    categories: categoryFromUrl ? [categoryFromUrl] : [],
    priceRange: [0, 1000],
    rating: null,
    onSale: false,
  });

  // Fetch products
  useEffect(() => {
    const fetchProducts = async () => {
      setIsLoading(true);
      try {
        const data = await getProducts();
        setProducts(data);
        setFilteredProducts(data);
        
        // Find max price for range slider
        if (data.length > 0) {
          const maxPrice = Math.max(...data.map(p => p.price));
          setFilters(prev => ({
            ...prev,
            priceRange: [0, Math.ceil(maxPrice / 100) * 100]
          }));
        }
      } catch (error) {
        console.error("Failed to fetch products:", error);
      } finally {
        setIsLoading(false);
      }
    };

    fetchProducts();
  }, []);

  // Apply filters and sorting
  useEffect(() => {
    let result = [...products];

    // Apply category filter
    if (filters.categories.length > 0) {
      result = result.filter(p => filters.categories.includes(p.category));
    }

    // Apply price range filter
    result = result.filter(
      p => {
        const price = p.salePrice || p.price;
        return price >= filters.priceRange[0] && price <= filters.priceRange[1];
      }
    );

    // Apply rating filter
    if (filters.rating) {
      result = result.filter(p => p.rating >= filters.rating);
    }

    // Apply sale filter
    if (filters.onSale) {
      result = result.filter(p => p.isSale);
    }

    // Apply sorting
    switch (sortBy) {
      case "price-low":
        result.sort((a, b) => {
          const priceA = a.salePrice || a.price;
          const priceB = b.salePrice || b.price;
          return priceA - priceB;
        });
        break;
      case "price-high":
        result.sort((a, b) => {
          const priceA = a.salePrice || a.price;
          const priceB = b.salePrice || b.price;
          return priceB - priceA;
        });
        break;
      case "rating":
        result.sort((a, b) => b.rating - a.rating);
        break;
      case "newest":
      default:
        result.sort((a, b) => (a.isNew === b.isNew ? 0 : a.isNew ? -1 : 1));
        break;
    }

    setFilteredProducts(result);
  }, [products, filters, sortBy]);

  const handleCategoryChange = (category: string) => {
    setFilters(prev => {
      const exists = prev.categories.includes(category);
      if (exists) {
        return {
          ...prev,
          categories: prev.categories.filter(c => c !== category)
        };
      } else {
        return {
          ...prev,
          categories: [...prev.categories, category]
        };
      }
    });
  };

  const handleRatingChange = (rating: number) => {
    setFilters(prev => ({
      ...prev,
      rating: prev.rating === rating ? null : rating
    }));
  };

  const resetFilters = () => {
    setFilters({
      categories: [],
      priceRange: [0, Math.max(...products.map(p => p.price))],
      rating: null,
      onSale: false
    });
    setSortBy("newest");
  };

  // Get unique categories
  const categories = [...new Set(products.map(p => p.category))];

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex flex-col md:flex-row gap-8">
        {/* Mobile Filter Toggle */}
        <div className="md:hidden flex justify-between items-center mb-4">
          <Button 
            variant="outline" 
            onClick={() => setShowFilters(!showFilters)}
            className="flex items-center gap-2"
          >
            <SlidersHorizontal size={16} />
            Filters
          </Button>
          
          <Select value={sortBy} onValueChange={setSortBy}>
            <SelectTrigger className="w-[180px]">
              <SelectValue placeholder="Sort By" />
            </SelectTrigger>
            <SelectContent>
              {sortOptions.map(option => (
                <SelectItem key={option.id} value={option.id}>
                  {option.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        {/* Filters sidebar - desktop always visible, mobile conditional */}
        <aside className={`w-full md:w-64 bg-white p-4 rounded-lg shadow-sm ${showFilters ? 'block' : 'hidden md:block'}`}>
          <div className="flex justify-between items-center mb-4">
            <h2 className="text-lg font-semibold">Filters</h2>
            <div className="flex items-center gap-2">
              <Button variant="ghost" size="sm" onClick={resetFilters} className="text-sm">
                Reset
              </Button>
              <Button 
                variant="ghost" 
                size="icon" 
                onClick={() => setShowFilters(false)}
                className="md:hidden"
              >
                <X size={18} />
              </Button>
            </div>
          </div>
          
          <Separator className="my-4" />
          
          <Accordion type="multiple" defaultValue={["category", "price", "rating"]}>
            <AccordionItem value="category">
              <AccordionTrigger>Categories</AccordionTrigger>
              <AccordionContent>
                <div className="space-y-2">
                  {categories.map(category => (
                    <div key={category} className="flex items-center gap-2">
                      <Checkbox 
                        id={`category-${category}`} 
                        checked={filters.categories.includes(category)}
                        onCheckedChange={() => handleCategoryChange(category)}
                      />
                      <label 
                        htmlFor={`category-${category}`}
                        className="text-sm cursor-pointer"
                      >
                        {category.charAt(0).toUpperCase() + category.slice(1)}
                      </label>
                    </div>
                  ))}
                </div>
              </AccordionContent>
            </AccordionItem>
            
            <AccordionItem value="price">
              <AccordionTrigger>Price Range</AccordionTrigger>
              <AccordionContent>
                <div className="px-2">
                  <Slider 
                    defaultValue={[0, 1000]}
                    value={filters.priceRange}
                    max={1000}
                    step={10}
                    onValueChange={(value) => 
                      setFilters(prev => ({ ...prev, priceRange: value as [number, number] }))
                    }
                    className="my-6"
                  />
                  <div className="flex justify-between text-sm">
                    <span>${filters.priceRange[0]}</span>
                    <span>${filters.priceRange[1]}</span>
                  </div>
                </div>
              </AccordionContent>
            </AccordionItem>
            
            <AccordionItem value="rating">
              <AccordionTrigger>Customer Rating</AccordionTrigger>
              <AccordionContent>
                <div className="space-y-2">
                  {[5, 4, 3, 2, 1].map(rating => (
                    <div 
                      key={rating} 
                      className={`flex items-center gap-1 p-1 rounded cursor-pointer ${
                        filters.rating === rating ? 'bg-primary/10' : ''
                      }`}
                      onClick={() => handleRatingChange(rating)}
                    >
                      {Array.from({ length: 5 }).map((_, i) => (
                        <Star 
                          key={i} 
                          size={16} 
                          className={i < rating ? 'fill-yellow-400 text-yellow-400' : 'text-gray-300'} 
                        />
                      ))}
                      <span className="text-sm ml-1">& Up</span>
                    </div>
                  ))}
                </div>
              </AccordionContent>
            </AccordionItem>
            
            <AccordionItem value="sale">
              <AccordionTrigger>Special Offers</AccordionTrigger>
              <AccordionContent>
                <div className="flex items-center gap-2">
                  <Checkbox 
                    id="on-sale" 
                    checked={filters.onSale}
                    onCheckedChange={(checked) => 
                      setFilters(prev => ({ ...prev, onSale: Boolean(checked) }))
                    }
                  />
                  <label htmlFor="on-sale" className="text-sm cursor-pointer">On Sale</label>
                </div>
              </AccordionContent>
            </AccordionItem>
          </Accordion>
        </aside>

        {/* Product grid */}
        <div className="flex-1">
          <div className="hidden md:flex justify-between items-center mb-6">
            <h1 className="text-2xl font-bold">
              {filters.categories.length === 1 
                ? filters.categories[0].charAt(0).toUpperCase() + filters.categories[0].slice(1)
                : "All Products"}
            </h1>
            
            <div className="flex items-center gap-2">
              <span className="text-sm text-gray-500">Sort by:</span>
              <Select value={sortBy} onValueChange={setSortBy}>
                <SelectTrigger className="w-[180px]">
                  <SelectValue placeholder="Sort By" />
                </SelectTrigger>
                <SelectContent>
                  {sortOptions.map(option => (
                    <SelectItem key={option.id} value={option.id}>
                      {option.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="mb-4">
            <p className="text-sm text-gray-500">
              Showing {filteredProducts.length} products
            </p>
          </div>

          {isLoading ? (
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
              {[...Array(8)].map((_, i) => (
                <div key={i} className="animate-pulse">
                  <div className="bg-gray-200 aspect-[3/4] rounded-lg mb-3"></div>
                  <div className="bg-gray-200 h-4 w-3/4 mb-2 rounded"></div>
                  <div className="bg-gray-200 h-3 w-1/2 mb-2 rounded"></div>
                  <div className="bg-gray-200 h-4 w-1/4 rounded"></div>
                </div>
              ))}
            </div>
          ) : filteredProducts.length > 0 ? (
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
              {filteredProducts.map(product => (
                <ProductCard key={product.id} product={product} />
              ))}
            </div>
          ) : (
            <div className="text-center py-16">
              <h3 className="text-xl font-semibold">No products found</h3>
              <p className="text-gray-500 mt-2">Try adjusting your filters to find what you're looking for.</p>
              <Button 
                variant="outline" 
                className="mt-4" 
                onClick={resetFilters}
              >
                Reset Filters
              </Button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
