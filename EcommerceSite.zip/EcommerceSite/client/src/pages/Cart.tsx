import { useState } from "react";
import { Link } from "wouter";
import { useCart } from "@/context/CartContext";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardFooter } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Separator } from "@/components/ui/separator";
import { formatCurrency } from "@/lib/utils";
import { Trash2, Plus, Minus, ChevronLeft, ShoppingBag } from "lucide-react";

export default function Cart() {
  const { cartItems, removeFromCart, updateQuantity, getCartTotal } = useCart();
  const [promoCode, setPromoCode] = useState("");
  const [promoApplied, setPromoApplied] = useState(false);
  
  const subtotal = getCartTotal();
  const shipping = subtotal > 50 ? 0 : 7.99;
  const discount = promoApplied ? subtotal * 0.1 : 0;
  const total = subtotal + shipping - discount;

  const handleApplyPromo = () => {
    if (promoCode.toLowerCase() === "discount10") {
      setPromoApplied(true);
    }
  };

  if (cartItems.length === 0) {
    return (
      <div className="container mx-auto px-4 py-16 text-center">
        <div className="max-w-md mx-auto">
          <ShoppingBag size={64} className="mx-auto text-gray-300 mb-6" />
          <h1 className="text-2xl font-bold mb-4">Your Cart is Empty</h1>
          <p className="text-gray-500 mb-8">Looks like you haven't added any products to your cart yet.</p>
          <Link href="/products">
            <Button size="lg">Start Shopping</Button>
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-2xl font-bold mb-8">Shopping Cart ({cartItems.length} items)</h1>
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Cart Items */}
        <div className="lg:col-span-2">
          <div className="bg-white rounded-lg shadow-sm overflow-hidden">
            {/* Header */}
            <div className="hidden md:grid grid-cols-12 p-4 bg-gray-50 text-sm font-medium text-gray-500">
              <div className="col-span-6">Product</div>
              <div className="col-span-2 text-center">Price</div>
              <div className="col-span-2 text-center">Quantity</div>
              <div className="col-span-2 text-center">Total</div>
            </div>
            
            {/* Cart Items */}
            <div className="divide-y">
              {cartItems.map((item) => {
                const { product } = item;
                const price = product.salePrice ?? product.price;
                const itemTotal = price * item.quantity;
                
                return (
                  <div key={item.id} className="p-4">
                    <div className="grid grid-cols-1 md:grid-cols-12 gap-4 items-center">
                      {/* Product Info */}
                      <div className="md:col-span-6 flex gap-4">
                        <div className="w-20 h-20 bg-gray-100 rounded overflow-hidden flex-shrink-0">
                          <img 
                            src={product.imageUrl} 
                            alt={product.name} 
                            className="w-full h-full object-cover"
                          />
                        </div>
                        <div>
                          <h3 className="font-medium">{product.name}</h3>
                          {item.color && (
                            <p className="text-sm text-gray-500 mt-1">
                              Color: {item.color}
                            </p>
                          )}
                          {item.size && (
                            <p className="text-sm text-gray-500 mt-1">
                              Size: {item.size}
                            </p>
                          )}
                          <button 
                            onClick={() => removeFromCart(item.id)}
                            className="text-sm text-gray-500 flex items-center mt-2 hover:text-red-500"
                          >
                            <Trash2 size={14} className="mr-1" />
                            Remove
                          </button>
                        </div>
                      </div>
                      
                      {/* Price */}
                      <div className="md:col-span-2 text-center flex md:block items-center justify-between">
                        <span className="md:hidden text-sm text-gray-500">Price:</span>
                        <span className="font-medium">{formatCurrency(price)}</span>
                      </div>
                      
                      {/* Quantity */}
                      <div className="md:col-span-2 flex justify-center">
                        <div className="flex items-center border rounded">
                          <button 
                            className="px-2 py-1 text-gray-500"
                            onClick={() => updateQuantity(item.id, item.quantity - 1)}
                            disabled={item.quantity <= 1}
                          >
                            <Minus size={14} />
                          </button>
                          <span className="px-2 py-1">{item.quantity}</span>
                          <button 
                            className="px-2 py-1 text-gray-500"
                            onClick={() => updateQuantity(item.id, item.quantity + 1)}
                          >
                            <Plus size={14} />
                          </button>
                        </div>
                      </div>
                      
                      {/* Total */}
                      <div className="md:col-span-2 text-center flex md:block items-center justify-between font-medium">
                        <span className="md:hidden text-sm text-gray-500">Total:</span>
                        {formatCurrency(itemTotal)}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
          
          <div className="mt-6 flex justify-between">
            <Link href="/products">
              <Button variant="outline" className="flex items-center">
                <ChevronLeft size={16} className="mr-2" />
                Continue Shopping
              </Button>
            </Link>
          </div>
        </div>
        
        {/* Order Summary */}
        <div>
          <Card>
            <CardContent className="p-6">
              <h2 className="text-xl font-bold mb-4">Order Summary</h2>
              
              <div className="space-y-3 text-sm">
                <div className="flex justify-between">
                  <span className="text-gray-600">Subtotal</span>
                  <span className="font-medium">{formatCurrency(subtotal)}</span>
                </div>
                
                <div className="flex justify-between">
                  <span className="text-gray-600">Shipping</span>
                  <span className="font-medium">
                    {shipping === 0 ? "Free" : formatCurrency(shipping)}
                  </span>
                </div>
                
                {promoApplied && (
                  <div className="flex justify-between text-green-600">
                    <span>Discount (10%)</span>
                    <span>-{formatCurrency(discount)}</span>
                  </div>
                )}
              </div>
              
              <Separator className="my-4" />
              
              <div className="flex justify-between font-bold text-lg mb-6">
                <span>Total</span>
                <span>{formatCurrency(total)}</span>
              </div>
              
              {/* Promo Code */}
              {!promoApplied ? (
                <div className="mb-4">
                  <p className="text-sm mb-2">Promo Code</p>
                  <div className="flex gap-2">
                    <Input 
                      placeholder="Enter code" 
                      value={promoCode}
                      onChange={(e) => setPromoCode(e.target.value)}
                    />
                    <Button 
                      variant="outline" 
                      onClick={handleApplyPromo}
                      disabled={!promoCode}
                    >
                      Apply
                    </Button>
                  </div>
                  <p className="text-xs text-gray-500 mt-1">
                    Try "DISCOUNT10" for 10% off
                  </p>
                </div>
              ) : (
                <div className="bg-green-50 p-3 rounded-md text-green-700 text-sm mb-4 flex justify-between">
                  <div className="flex items-center">
                    <span>Code "DISCOUNT10" applied!</span>
                  </div>
                  <button 
                    className="text-green-800 hover:text-red-500"
                    onClick={() => {
                      setPromoApplied(false);
                      setPromoCode("");
                    }}
                  >
                    Remove
                  </button>
                </div>
              )}
              
              <p className="text-sm text-gray-500 mb-6">
                Shipping calculated at checkout. Free shipping on orders over $50.
              </p>
              
              <Link href="/checkout">
                <Button className="w-full" size="lg">
                  Proceed to Checkout
                </Button>
              </Link>
            </CardContent>
            
            <CardFooter className="bg-gray-50 px-6 py-4 text-sm text-gray-500 flex justify-center gap-4">
              <img 
                src="https://upload.wikimedia.org/wikipedia/commons/thumb/5/5e/Visa_Inc._logo.svg/2560px-Visa_Inc._logo.svg.png" 
                alt="Visa" 
                className="h-6"
              />
              <img 
                src="https://upload.wikimedia.org/wikipedia/commons/thumb/2/2a/Mastercard-logo.svg/1280px-Mastercard-logo.svg.png" 
                alt="Mastercard" 
                className="h-6"
              />
              <img 
                src="https://upload.wikimedia.org/wikipedia/commons/thumb/b/b5/PayPal.svg/1280px-PayPal.svg.png" 
                alt="PayPal" 
                className="h-6"
              />
              <img 
                src="https://upload.wikimedia.org/wikipedia/commons/thumb/f/fa/American_Express_logo_%282018%29.svg/1200px-American_Express_logo_%282018%29.svg.png" 
                alt="American Express" 
                className="h-6"
              />
            </CardFooter>
          </Card>
        </div>
      </div>
    </div>
  );
}
