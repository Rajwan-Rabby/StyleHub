import { useState, useEffect } from "react";
import { useRoute, Link } from "wouter";
import { getProductById, getProducts } from "@/data/products";
import { Product } from "@/lib/types";
import { useCart } from "@/context/CartContext";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Separator } from "@/components/ui/separator";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Breadcrumb, BreadcrumbItem, BreadcrumbLink } from "@/components/ui/breadcrumb";
import ProductCard from "@/components/ProductCard";
import { formatCurrency, generateStars } from "@/lib/utils";
import { Star, ChevronRight, Minus, Plus, Heart, Share2, Truck, RotateCcw, Shield } from "lucide-react";

export default function ProductDetail() {
  const [, params] = useRoute("/product/:id");
  const productId = params?.id ? parseInt(params.id) : null;
  
  const [product, setProduct] = useState<Product | null>(null);
  const [relatedProducts, setRelatedProducts] = useState<Product[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [quantity, setQuantity] = useState(1);
  const [selectedColor, setSelectedColor] = useState<string | undefined>(undefined);
  const [selectedSize, setSelectedSize] = useState<string | undefined>(undefined);
  const [activeImage, setActiveImage] = useState(0);
  
  const { addToCart } = useCart();

  // Fetch product and related products
  useEffect(() => {
    const fetchProduct = async () => {
      if (!productId) return;
      
      setIsLoading(true);
      try {
        const productData = await getProductById(productId);
        setProduct(productData);
        
        // Get related products (same category)
        const allProducts = await getProducts();
        const related = allProducts
          .filter(p => p.id !== productId && p.category === productData.category)
          .slice(0, 4);
        setRelatedProducts(related);
        
        // Set default selected options if available
        if (productData.colors.length > 0) {
          setSelectedColor(productData.colors[0]);
        }
        if (productData.sizes.length > 0) {
          setSelectedSize(productData.sizes[0]);
        }
      } catch (error) {
        console.error("Failed to fetch product:", error);
      } finally {
        setIsLoading(false);
      }
    };

    fetchProduct();
  }, [productId]);

  const handleQuantityChange = (amount: number) => {
    const newQuantity = quantity + amount;
    if (newQuantity >= 1 && newQuantity <= (product?.stockCount || 10)) {
      setQuantity(newQuantity);
    }
  };

  const handleAddToCart = () => {
    if (product) {
      addToCart(product, quantity, selectedColor, selectedSize);
    }
  };

  // Loading state
  if (isLoading) {
    return (
      <div className="container mx-auto px-4 py-8">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          <div className="animate-pulse bg-gray-200 rounded-lg aspect-square"></div>
          <div className="space-y-4">
            <div className="h-8 bg-gray-200 rounded w-3/4"></div>
            <div className="h-6 bg-gray-200 rounded w-1/4"></div>
            <div className="h-4 bg-gray-200 rounded w-full"></div>
            <div className="h-4 bg-gray-200 rounded w-full"></div>
            <div className="h-12 bg-gray-200 rounded w-1/2 mt-6"></div>
          </div>
        </div>
      </div>
    );
  }

  // Product not found
  if (!product) {
    return (
      <div className="container mx-auto px-4 py-16 text-center">
        <h1 className="text-2xl font-bold mb-4">Product Not Found</h1>
        <p className="mb-8">The product you're looking for doesn't exist or has been removed.</p>
        <Link href="/products">
          <Button>Continue Shopping</Button>
        </Link>
      </div>
    );
  }

  const { rating, reviewCount } = product;
  const stars = generateStars(rating);
  
  // Gallery images (using the main image for now, in a real app you'd have multiple images)
  const galleryImages = [
    product.imageUrl,
    product.imageUrl,
    product.imageUrl,
    product.imageUrl,
  ];

  return (
    <div className="container mx-auto px-4 py-8">
      {/* Breadcrumb */}
      <Breadcrumb className="mb-6">
        <BreadcrumbItem>
          <BreadcrumbLink asChild>
            <Link href="/">Home</Link>
          </BreadcrumbLink>
        </BreadcrumbItem>
        <BreadcrumbItem>
          <BreadcrumbLink asChild>
            <Link href="/products">Products</Link>
          </BreadcrumbLink>
        </BreadcrumbItem>
        <BreadcrumbItem>
          <BreadcrumbLink asChild>
            <Link href={`/products?category=${product.category}`}>
              {product.category.charAt(0).toUpperCase() + product.category.slice(1)}
            </Link>
          </BreadcrumbLink>
        </BreadcrumbItem>
        <BreadcrumbItem isCurrentPage>
          <BreadcrumbLink>{product.name}</BreadcrumbLink>
        </BreadcrumbItem>
      </Breadcrumb>

      {/* Product Details */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-16">
        {/* Product Gallery */}
        <div className="space-y-4">
          <div className="bg-gray-100 rounded-lg overflow-hidden">
            <img 
              src={galleryImages[activeImage]} 
              alt={product.name} 
              className="w-full h-auto object-cover aspect-square"
            />
          </div>
          <div className="grid grid-cols-4 gap-2">
            {galleryImages.map((image, index) => (
              <div 
                key={index}
                className={`cursor-pointer border-2 rounded-md overflow-hidden ${
                  activeImage === index ? 'border-primary' : 'border-transparent'
                }`}
                onClick={() => setActiveImage(index)}
              >
                <img 
                  src={image} 
                  alt={`${product.name} view ${index + 1}`} 
                  className="w-full h-auto aspect-square object-cover"
                />
              </div>
            ))}
          </div>
        </div>

        {/* Product Info */}
        <div>
          <h1 className="text-2xl md:text-3xl font-bold mb-2">{product.name}</h1>
          
          {/* Rating */}
          <div className="flex items-center space-x-1 mb-4">
            <div className="flex text-yellow-400">
              {[...Array(5)].map((_, i) => (
                <Star
                  key={i}
                  size={18}
                  className={i < stars.full ? 'fill-yellow-400' : i < stars.full + stars.half ? 'fill-yellow-400/50' : 'text-gray-300'}
                />
              ))}
            </div>
            <span className="text-sm text-gray-500">({reviewCount} reviews)</span>
          </div>
          
          {/* Price */}
          <div className="mb-6">
            {product.salePrice ? (
              <div className="flex items-center">
                <span className="text-2xl font-semibold">{formatCurrency(product.salePrice)}</span>
                <span className="text-gray-500 line-through ml-2">{formatCurrency(product.price)}</span>
                <span className="text-xs text-white bg-secondary px-2 py-1 rounded ml-2">
                  SALE
                </span>
              </div>
            ) : (
              <span className="text-2xl font-semibold">{formatCurrency(product.price)}</span>
            )}
          </div>
          
          {/* Description */}
          <p className="text-gray-600 mb-6">{product.description}</p>
          
          <Separator className="my-6" />
          
          {/* Color Selection */}
          {product.colors.length > 0 && (
            <div className="mb-6">
              <h3 className="text-sm font-medium mb-3">Color</h3>
              <div className="flex space-x-2">
                {product.colors.map(color => (
                  <button
                    key={color}
                    onClick={() => setSelectedColor(color)}
                    className={`w-8 h-8 rounded-full border ${
                      selectedColor === color ? 'ring-2 ring-primary ring-offset-2' : 'ring-0'
                    }`}
                    style={{ backgroundColor: color.toLowerCase() }}
                    aria-label={color}
                  />
                ))}
              </div>
              {selectedColor && (
                <p className="text-sm text-gray-500 mt-2">Selected: {selectedColor}</p>
              )}
            </div>
          )}
          
          {/* Size Selection */}
          {product.sizes.length > 0 && (
            <div className="mb-6">
              <div className="flex justify-between items-center mb-3">
                <h3 className="text-sm font-medium">Size</h3>
                <button className="text-sm text-primary">Size Guide</button>
              </div>
              <Select 
                value={selectedSize} 
                onValueChange={setSelectedSize}
              >
                <SelectTrigger className="w-full">
                  <SelectValue placeholder="Select a size" />
                </SelectTrigger>
                <SelectContent>
                  {product.sizes.map(size => (
                    <SelectItem key={size} value={size}>
                      {size}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          )}
          
          {/* Quantity */}
          <div className="mb-6">
            <h3 className="text-sm font-medium mb-3">Quantity</h3>
            <div className="flex items-center">
              <Button 
                variant="outline" 
                size="icon" 
                onClick={() => handleQuantityChange(-1)}
                disabled={quantity <= 1}
              >
                <Minus size={16} />
              </Button>
              <span className="w-12 text-center font-medium">{quantity}</span>
              <Button 
                variant="outline" 
                size="icon" 
                onClick={() => handleQuantityChange(1)}
                disabled={quantity >= product.stockCount}
              >
                <Plus size={16} />
              </Button>
              <span className="ml-4 text-sm text-gray-500">
                {product.stockCount} available
              </span>
            </div>
          </div>
          
          {/* Add to Cart */}
          <div className="flex flex-col sm:flex-row gap-4 mb-6">
            <Button 
              size="xl"
              className="flex-1"
              onClick={handleAddToCart}
            >
              Add to Cart
            </Button>
            <Button 
              variant="outline" 
              size="icon" 
              className="h-12 w-12"
            >
              <Heart size={20} />
            </Button>
            <Button 
              variant="outline" 
              size="icon" 
              className="h-12 w-12"
            >
              <Share2 size={20} />
            </Button>
          </div>
          
          {/* Shipping Info */}
          <div className="space-y-4 text-sm">
            <div className="flex items-start">
              <Truck className="h-5 w-5 text-primary mr-3 mt-0.5" />
              <div>
                <h4 className="font-medium">Free Shipping</h4>
                <p className="text-gray-500">On orders over $50</p>
              </div>
            </div>
            <div className="flex items-start">
              <RotateCcw className="h-5 w-5 text-primary mr-3 mt-0.5" />
              <div>
                <h4 className="font-medium">Easy Returns</h4>
                <p className="text-gray-500">30 days return policy</p>
              </div>
            </div>
            <div className="flex items-start">
              <Shield className="h-5 w-5 text-primary mr-3 mt-0.5" />
              <div>
                <h4 className="font-medium">Secure Checkout</h4>
                <p className="text-gray-500">Protected by encryption</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Product Tabs */}
      <Tabs defaultValue="description" className="mb-16">
        <TabsList className="w-full border-b justify-start rounded-none">
          <TabsTrigger value="description">Description</TabsTrigger>
          <TabsTrigger value="specification">Specification</TabsTrigger>
          <TabsTrigger value="reviews" className="flex items-center">
            Reviews 
            <span className="ml-1 text-xs bg-gray-100 px-2 py-0.5 rounded-full">
              {reviewCount}
            </span>
          </TabsTrigger>
        </TabsList>
        <TabsContent value="description" className="py-4">
          <div className="prose max-w-none">
            <p>{product.description}</p>
            <p>
              Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed euismod 
              magna vel nunc faucibus, quis varius nisl vulputate. Suspendisse 
              eget nisl nec enim tincidunt venenatis. Vivamus suscipit libero ac 
              lorem elementum, vel faucibus nisi tincidunt.
            </p>
            <ul>
              <li>High-quality materials for durability</li>
              <li>Comfortable fit for all-day wear</li>
              <li>Versatile design for various occasions</li>
              <li>Easy care and maintenance</li>
            </ul>
          </div>
        </TabsContent>
        <TabsContent value="specification" className="py-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <h3 className="text-lg font-medium mb-2">Product Details</h3>
              <ul className="space-y-2 text-sm">
                <li className="flex">
                  <span className="w-24 font-medium">Material:</span>
                  <span className="text-gray-600">100% Cotton</span>
                </li>
                <li className="flex">
                  <span className="w-24 font-medium">Pattern:</span>
                  <span className="text-gray-600">Solid</span>
                </li>
                <li className="flex">
                  <span className="w-24 font-medium">Origin:</span>
                  <span className="text-gray-600">Imported</span>
                </li>
                <li className="flex">
                  <span className="w-24 font-medium">Item Code:</span>
                  <span className="text-gray-600">PROD-{product.id}</span>
                </li>
              </ul>
            </div>
            <div>
              <h3 className="text-lg font-medium mb-2">Dimensions & Fit</h3>
              <ul className="space-y-2 text-sm">
                <li className="flex">
                  <span className="w-24 font-medium">Fit:</span>
                  <span className="text-gray-600">Regular fit</span>
                </li>
                <li className="flex">
                  <span className="w-24 font-medium">Length:</span>
                  <span className="text-gray-600">Standard</span>
                </li>
                <li className="flex">
                  <span className="w-24 font-medium">Care:</span>
                  <span className="text-gray-600">Machine washable</span>
                </li>
              </ul>
            </div>
          </div>
        </TabsContent>
        <TabsContent value="reviews" className="py-4">
          <div className="flex flex-col md:flex-row gap-8">
            <div className="md:w-1/3">
              <div className="bg-gray-50 p-4 rounded-lg">
                <h3 className="text-xl font-bold mb-2">{rating.toFixed(1)}</h3>
                <div className="flex text-yellow-400 mb-2">
                  {[...Array(5)].map((_, i) => (
                    <Star
                      key={i}
                      size={18}
                      className={i < stars.full ? 'fill-yellow-400' : i < stars.full + stars.half ? 'fill-yellow-400/50' : 'text-gray-300'}
                    />
                  ))}
                </div>
                <p className="text-sm text-gray-500">Based on {reviewCount} reviews</p>
                
                <Separator className="my-4" />
                
                <div className="space-y-2">
                  {[5, 4, 3, 2, 1].map(star => {
                    // Mock percentage based on the rating
                    const percentage = star === Math.round(rating) 
                      ? 60 
                      : star > Math.round(rating) 
                        ? Math.max(0, 80 - (star - Math.round(rating)) * 30) 
                        : Math.max(0, 80 - (Math.round(rating) - star) * 30);
                    
                    return (
                      <div key={star} className="flex items-center">
                        <div className="flex items-center w-10">
                          <span className="text-sm">{star}</span>
                          <Star size={12} className="ml-1 fill-yellow-400 text-yellow-400" />
                        </div>
                        <div className="flex-1 mx-2 h-2 rounded-full bg-gray-200 overflow-hidden">
                          <div 
                            className="h-full bg-yellow-400" 
                            style={{ width: `${percentage}%` }}
                          ></div>
                        </div>
                        <span className="text-xs text-gray-500 w-10 text-right">
                          {Math.round((percentage / 100) * reviewCount)}
                        </span>
                      </div>
                    );
                  })}
                </div>
                
                <Button className="w-full mt-4">Write a Review</Button>
              </div>
            </div>
            
            <div className="md:w-2/3 space-y-6">
              {/* Mock reviews */}
              {[...Array(3)].map((_, i) => (
                <Card key={i} className="p-4">
                  <div className="flex justify-between mb-2">
                    <div>
                      <h4 className="font-medium">Customer Name</h4>
                      <div className="flex text-yellow-400 my-1">
                        {[...Array(5)].map((_, j) => (
                          <Star
                            key={j}
                            size={14}
                            className={j < 4 + Math.min(i, 1) ? 'fill-yellow-400' : 'text-gray-300'}
                          />
                        ))}
                      </div>
                    </div>
                    <span className="text-sm text-gray-500">
                      {i === 0 ? '3 days ago' : i === 1 ? '1 week ago' : '2 weeks ago'}
                    </span>
                  </div>
                  <h5 className="font-medium mb-2">
                    {i === 0 ? 'Great quality and fit!' : i === 1 ? 'Exactly as described' : 'Love it!'}
                  </h5>
                  <p className="text-sm text-gray-600">
                    {i === 0 
                      ? "I'm extremely happy with this purchase. The material is excellent, and it fits perfectly. Will definitely order more."
                      : i === 1 
                        ? "The product arrived quickly and looks exactly like the pictures. Very satisfied with my purchase."
                        : "This is now my favorite item in my wardrobe. The quality exceeded my expectations."
                    }
                  </p>
                </Card>
              ))}
              
              <Button variant="outline" className="w-full">Load More Reviews</Button>
            </div>
          </div>
        </TabsContent>
      </Tabs>

      {/* Related Products */}
      {relatedProducts.length > 0 && (
        <div>
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-2xl font-bold">You May Also Like</h2>
            <Link href="/products">
              <Button variant="link" className="text-primary font-medium hover:text-primary/90 flex items-center">
                View All
                <ChevronRight size={16} className="ml-1" />
              </Button>
            </Link>
          </div>
          
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 md:gap-6">
            {relatedProducts.map(product => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
