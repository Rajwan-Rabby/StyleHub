import { useEffect, useState } from "react";
import { CheckCircle } from "lucide-react";

export default function Toast() {
  const [message, setMessage] = useState<string | null>(null);
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    // Listen for custom toast events
    const handleShowToast = (event: Event) => {
      if (event instanceof CustomEvent) {
        setMessage(event.detail);
        setIsVisible(true);
        
        // Hide toast after 3 seconds
        setTimeout(() => {
          setIsVisible(false);
          setTimeout(() => setMessage(null), 300); // Clear message after fade out
        }, 3000);
      }
    };

    window.addEventListener('showToast', handleShowToast);
    
    return () => {
      window.removeEventListener('showToast', handleShowToast);
    };
  }, []);

  if (!message) return null;

  return (
    <div 
      className={`fixed bottom-4 right-4 bg-gray-800 text-white px-4 py-3 rounded-lg shadow-lg flex items-center transition-opacity duration-300 z-50 ${
        isVisible ? 'opacity-100' : 'opacity-0 pointer-events-none'
      }`}
    >
      <CheckCircle className="h-5 w-5 mr-2 text-green-400" />
      <span>{message}</span>
    </div>
  );
}
