import { Link } from "wouter";
import { Button } from "@/components/ui/button";

export default function PromoSection() {
  const promos = [
    {
      id: 1,
      title: "Summer Collection",
      description: "Discover our latest summer styles with up to 30% off",
      imageUrl: "https://images.unsplash.com/photo-1534452203293-494d7ddbf7e0?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80",
      buttonText: "Shop Now",
      buttonLink: "/products?category=summer",
      bgColor: "from-primary-700 to-primary-500"
    },
    {
      id: 2,
      title: "New Accessories",
      description: "Complete your look with our trendy accessories",
      imageUrl: "https://images.unsplash.com/photo-1556306535-0f09a537f0a3?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80",
      buttonText: "Shop Now",
      buttonLink: "/products?category=accessories",
      bgColor: "from-secondary to-accent"
    }
  ];

  return (
    <section className="py-16 bg-white">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {promos.map(promo => (
            <div key={promo.id} className="relative overflow-hidden rounded-xl">
              <div className={`bg-gradient-to-r ${promo.bgColor}`}>
                <img 
                  src={promo.imageUrl} 
                  alt={promo.title} 
                  className="w-full h-80 object-cover mix-blend-overlay"
                />
              </div>
              <div className="absolute inset-0 p-8 flex flex-col justify-center">
                <h3 className="text-white text-3xl font-bold mb-2">{promo.title}</h3>
                <p className="text-white text-lg mb-4 max-w-xs">{promo.description}</p>
                <Link href={promo.buttonLink}>
                  <Button 
                    variant="white" 
                    className={`text-${promo.bgColor.split('-')[0].split('from-')[1]} w-max`}
                  >
                    {promo.buttonText}
                  </Button>
                </Link>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
