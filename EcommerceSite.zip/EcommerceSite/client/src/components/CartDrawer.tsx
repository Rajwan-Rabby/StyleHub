import { Link } from "wouter";
import { useCart } from "@/context/CartContext";
import { Button } from "@/components/ui/button";
import { formatCurrency } from "@/lib/utils";
import { X, Plus, Minus } from "lucide-react";

interface CartDrawerProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function CartDrawer({ isOpen, onClose }: CartDrawerProps) {
  const { cartItems, removeFromCart, updateQuantity, getCartTotal } = useCart();
  
  const subtotal = getCartTotal();
  
  const handleCheckout = () => {
    onClose();
  };

  const handleContinueShopping = () => {
    onClose();
  };

  return (
    <div 
      className={`fixed inset-0 bg-black bg-opacity-50 z-50 ${isOpen ? 'block' : 'hidden'}`}
      onClick={onClose}
    >
      <div 
        className={`fixed top-0 right-0 h-full w-full max-w-md bg-white shadow-lg transform transition-transform duration-300 ease-in-out ${
          isOpen ? 'translate-x-0' : 'translate-x-full'
        }`}
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex justify-between items-center p-4 border-b">
          <h2 className="font-semibold text-lg">
            Your Cart ({cartItems.reduce((acc, item) => acc + item.quantity, 0)})
          </h2>
          <Button variant="ghost" size="icon" onClick={onClose}>
            <X className="h-6 w-6" />
          </Button>
        </div>
        
        {cartItems.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-[calc(100vh-240px)] p-4">
            <div className="w-24 h-24 bg-gray-100 rounded-full flex items-center justify-center mb-4">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-12 w-12 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M16 11V7a4 4 0 00-8 0v4M5 9h14l1 12H4L5 9z" />
              </svg>
            </div>
            <p className="text-lg font-medium mb-2">Your cart is empty</p>
            <p className="text-gray-500 text-center mb-6">Looks like you haven't added any products to your cart yet.</p>
            <Button onClick={handleContinueShopping}>Start Shopping</Button>
          </div>
        ) : (
          <>
            <div className="overflow-y-auto h-[calc(100vh-240px)] p-4 space-y-4">
              {cartItems.map((item) => {
                const { product } = item;
                const price = product.salePrice ?? product.price;
                
                return (
                  <div key={item.id} className="flex items-start border-b pb-4">
                    <img 
                      src={product.imageUrl} 
                      alt={product.name} 
                      className="w-20 h-20 object-cover rounded"
                    />
                    <div className="ml-3 flex-1">
                      <div className="flex justify-between">
                        <h4 className="font-medium">{product.name}</h4>
                        <button 
                          className="text-gray-400 hover:text-red-500"
                          onClick={() => removeFromCart(item.id)}
                        >
                          <X className="h-4 w-4" />
                        </button>
                      </div>
                      {item.color && <p className="text-sm text-gray-500">Color: {item.color}</p>}
                      {item.size && <p className="text-sm text-gray-500">Size: {item.size}</p>}
                      <div className="flex justify-between items-center mt-2">
                        <div className="flex items-center border rounded">
                          <button 
                            className="px-2 py-1 text-gray-500"
                            onClick={() => updateQuantity(item.id, item.quantity - 1)}
                            disabled={item.quantity <= 1}
                          >
                            <Minus className="h-3 w-3" />
                          </button>
                          <span className="px-2 py-1">{item.quantity}</span>
                          <button 
                            className="px-2 py-1 text-gray-500"
                            onClick={() => updateQuantity(item.id, item.quantity + 1)}
                          >
                            <Plus className="h-3 w-3" />
                          </button>
                        </div>
                        <span className="font-medium">{formatCurrency(price)}</span>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
            
            <div className="border-t p-4 bg-gray-50">
              <div className="flex justify-between mb-2">
                <span>Subtotal</span>
                <span className="font-medium">{formatCurrency(subtotal)}</span>
              </div>
              <div className="flex justify-between mb-4">
                <span>Shipping</span>
                <span className="font-medium">Calculated at checkout</span>
              </div>
              <Link href="/checkout" onClick={handleCheckout}>
                <Button className="w-full mb-2">
                  Checkout
                </Button>
              </Link>
              <Link href="/cart" onClick={handleCheckout}>
                <Button variant="outline" className="w-full">
                  View Cart
                </Button>
              </Link>
              <Button 
                variant="ghost" 
                className="w-full mt-2" 
                onClick={handleContinueShopping}
              >
                Continue Shopping
              </Button>
            </div>
          </>
        )}
      </div>
    </div>
  );
}
