import { useState } from "react";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { X } from "lucide-react";

interface MobileMenuProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function MobileMenu({ isOpen, onClose }: MobileMenuProps) {
  const [expandedCategories, setExpandedCategories] = useState<string[]>([]);
  
  const toggleCategory = (category: string) => {
    if (expandedCategories.includes(category)) {
      setExpandedCategories(expandedCategories.filter(c => c !== category));
    } else {
      setExpandedCategories([...expandedCategories, category]);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 z-50">
      <div 
        className={`fixed top-0 left-0 h-full w-64 bg-white shadow-lg transform transition-transform duration-300 ease-in-out ${
          isOpen ? 'translate-x-0' : '-translate-x-full'
        }`}
      >
        <div className="flex justify-between items-center p-4 border-b">
          <h2 className="font-semibold text-lg">Menu</h2>
          <Button variant="ghost" size="icon" onClick={onClose}>
            <X className="h-6 w-6 text-gray-500 hover:text-gray-700" />
          </Button>
        </div>
        
        <nav className="p-4 space-y-4">
          <Link href="/" onClick={onClose} className="block font-medium py-2 border-b border-gray-200">
            Home
          </Link>
          
          <div>
            <button 
              className="flex justify-between items-center w-full font-medium py-2"
              onClick={() => toggleCategory('women')}
            >
              Women
              <svg 
                xmlns="http://www.w3.org/2000/svg" 
                className={`h-4 w-4 transition-transform ${expandedCategories.includes('women') ? 'rotate-180' : ''}`}
                fill="none" 
                viewBox="0 0 24 24" 
                stroke="currentColor"
              >
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 9l-7 7-7-7" />
              </svg>
            </button>
            <div className={`pl-4 space-y-2 ${expandedCategories.includes('women') ? 'block' : 'hidden'}`}>
              <Link href="/products?category=dresses" onClick={onClose} className="block py-1 text-gray-700">
                Dresses
              </Link>
              <Link href="/products?category=tops" onClick={onClose} className="block py-1 text-gray-700">
                Tops
              </Link>
              <Link href="/products?category=bottoms" onClick={onClose} className="block py-1 text-gray-700">
                Bottoms
              </Link>
              <Link href="/products?category=accessories" onClick={onClose} className="block py-1 text-gray-700">
                Accessories
              </Link>
            </div>
          </div>
          
          <div>
            <button 
              className="flex justify-between items-center w-full font-medium py-2"
              onClick={() => toggleCategory('men')}
            >
              Men
              <svg 
                xmlns="http://www.w3.org/2000/svg" 
                className={`h-4 w-4 transition-transform ${expandedCategories.includes('men') ? 'rotate-180' : ''}`}
                fill="none" 
                viewBox="0 0 24 24" 
                stroke="currentColor"
              >
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 9l-7 7-7-7" />
              </svg>
            </button>
            <div className={`pl-4 space-y-2 ${expandedCategories.includes('men') ? 'block' : 'hidden'}`}>
              <Link href="/products?category=shirts" onClick={onClose} className="block py-1 text-gray-700">
                Shirts
              </Link>
              <Link href="/products?category=pants" onClick={onClose} className="block py-1 text-gray-700">
                Pants
              </Link>
              <Link href="/products?category=shoes" onClick={onClose} className="block py-1 text-gray-700">
                Shoes
              </Link>
              <Link href="/products?category=accessories" onClick={onClose} className="block py-1 text-gray-700">
                Accessories
              </Link>
            </div>
          </div>
          
          <Link href="/products?category=kids" onClick={onClose} className="block font-medium py-2 border-b border-gray-200">
            Kids
          </Link>
          
          <Link href="/products?category=sale" onClick={onClose} className="block font-medium py-2 border-b border-gray-200">
            Sale
          </Link>
          
          <Link href="/products?new=true" onClick={onClose} className="block font-medium py-2 border-b border-gray-200 text-primary">
            New Arrivals
          </Link>
        </nav>
      </div>
    </div>
  );
}
