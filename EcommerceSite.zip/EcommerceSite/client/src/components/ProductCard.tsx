import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { useCart } from "@/context/CartContext";
import { Product } from "@/lib/types";
import { formatCurrency } from "@/lib/utils";
import { Heart, Star } from "lucide-react";

interface ProductCardProps {
  product: Product;
}

export default function ProductCard({ product }: ProductCardProps) {
  const { addToCart } = useCart();
  
  const {
    id,
    name,
    price,
    salePrice,
    imageUrl,
    rating,
    reviewCount,
    isNew,
    isSale
  } = product;

  const handleAddToCart = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    addToCart(product, 1);
  };
  
  return (
    <div className="group">
      <Link href={`/product/${id}`} className="block">
          <div className="relative overflow-hidden bg-gray-100 rounded-lg aspect-[3/4] mb-3">
            <img 
              src={imageUrl} 
              alt={name} 
              className="w-full h-full object-cover object-center transition duration-300 group-hover:scale-105"
            />
            <div className="absolute inset-0 bg-black bg-opacity-20 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center">
              <Button
                className="bg-white text-gray-800 transform -translate-y-2 group-hover:translate-y-0 transition-transform duration-300 hover:bg-gray-100"
                onClick={handleAddToCart}
              >
                Add to Cart
              </Button>
            </div>
            
            {isSale && (
              <div className="absolute top-2 left-2">
                <span className="bg-accent text-white text-xs px-2 py-1 rounded-md">Sale</span>
              </div>
            )}
            
            {isNew && !isSale && (
              <div className="absolute top-2 left-2">
                <span className="bg-primary text-white text-xs px-2 py-1 rounded-md">New</span>
              </div>
            )}
            
            <div className="absolute top-2 right-2">
              <button className="bg-white rounded-full p-2 shadow-sm hover:bg-gray-100">
                <Heart className="h-5 w-5 text-gray-600" />
              </button>
            </div>
          </div>
          
          <div>
            <h3 className="font-medium">{name}</h3>
            <div className="flex items-center space-x-1 mt-1">
              <div className="flex text-yellow-400">
                {[...Array(5)].map((_, i) => (
                  <Star 
                    key={i} 
                    className={`h-4 w-4 ${i < Math.floor(rating) ? 'fill-yellow-400' : 'text-gray-300'}`}
                  />
                ))}
              </div>
              <span className="text-sm text-gray-500">({reviewCount})</span>
            </div>
            <div className="mt-1 flex items-center justify-between">
              {salePrice ? (
                <div>
                  <span className="font-medium text-gray-900">{formatCurrency(salePrice)}</span>
                  <span className="text-sm text-gray-500 line-through ml-2">{formatCurrency(price)}</span>
                </div>
              ) : (
                <span className="font-medium text-gray-900">{formatCurrency(price)}</span>
              )}
              
              {isNew && <span className="text-sm text-gray-500">New</span>}
            </div>
          </div>
      </Link>
    </div>
  );
}
