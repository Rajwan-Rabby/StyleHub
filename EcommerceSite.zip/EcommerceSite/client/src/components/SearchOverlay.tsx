import { useState } from "react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { X, Search } from "lucide-react";

interface SearchOverlayProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function SearchOverlay({ isOpen, onClose }: SearchOverlayProps) {
  const [searchQuery, setSearchQuery] = useState("");
  const [, navigate] = useLocation();

  const popularSearches = [
    "Summer dresses",
    "Men's shorts",
    "Sandals",
    "Accessories"
  ];

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      navigate(`/products?search=${encodeURIComponent(searchQuery.trim())}`);
      onClose();
    }
  };

  const handlePopularSearch = (term: string) => {
    navigate(`/products?search=${encodeURIComponent(term)}`);
    onClose();
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-gray-900 bg-opacity-50 z-50 flex items-start justify-center pt-24 px-4">
      <div className="bg-white p-6 rounded-lg shadow-xl relative w-full max-w-2xl">
        <Button
          variant="ghost"
          size="icon"
          className="absolute top-4 right-4 text-gray-500 hover:text-gray-700"
          onClick={onClose}
        >
          <X className="h-6 w-6" />
        </Button>
        
        <h3 className="text-lg font-semibold mb-4">Search our store</h3>
        
        <form onSubmit={handleSearch}>
          <div className="relative">
            <Input
              type="text"
              placeholder="Search products..."
              className="w-full border border-gray-300 rounded-lg py-3 px-4 pr-10 focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              autoFocus
            />
            <Button
              type="submit"
              variant="ghost"
              size="icon"
              className="absolute right-3 top-3 text-gray-500"
            >
              <Search className="h-5 w-5" />
            </Button>
          </div>
        </form>
        
        <div className="mt-6">
          <h4 className="font-medium text-sm mb-2">Popular Searches:</h4>
          <div className="flex flex-wrap gap-2">
            {popularSearches.map((term, index) => (
              <button
                key={index}
                className="bg-gray-100 px-3 py-1 rounded-full text-sm hover:bg-gray-200"
                onClick={() => handlePopularSearch(term)}
              >
                {term}
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
