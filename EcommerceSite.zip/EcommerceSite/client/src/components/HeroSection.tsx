import { Link } from "wouter";
import { Button } from "@/components/ui/button";

export default function HeroSection() {
  return (
    <section className="relative bg-gray-900 overflow-hidden">
      {/* Main hero section */}
      <div className="relative">
        <div className="bg-gradient-to-r from-gray-900 via-slate-900 to-gray-900">
          <img 
            src="https://images.unsplash.com/photo-1581338834647-b0fb40704e21?ixlib=rb-1.2.1&auto=format&fit=crop&w=1920&q=80" 
            alt="Summer collection" 
            className="w-full h-[70vh] md:h-[80vh] object-cover object-center mix-blend-soft-light opacity-30"
          />
          {/* Decorative elements for automation theme */}
          <div className="absolute inset-0 overflow-hidden">
            <div className="absolute top-1/4 left-1/3 w-64 h-64 rounded-full bg-cyan-500/10 blur-3xl animate-pulse"></div>
            <div className="absolute top-1/2 right-1/4 w-96 h-96 rounded-full bg-indigo-500/10 blur-3xl animate-pulse delay-700"></div>
            <div className="absolute bottom-1/3 left-1/2 w-48 h-48 rounded-full bg-emerald-500/10 blur-3xl animate-pulse delay-1000"></div>
            
            {/* Circuit board pattern overlay */}
            <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjAiIGhlaWdodD0iNjAiIHZpZXdCb3g9IjAgMCA2MCA2MCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyBzdHJva2U9IiMzMzMiIHN0cm9rZS13aWR0aD0iLjUiIGZpbGw9Im5vbmUiIGZpbGwtcnVsZT0iZXZlbm9kZCI+PGNpcmNsZSBjeD0iNSIgY3k9IjUiIHI9IjIiLz48Y2lyY2xlIGN4PSI1NSIgY3k9IjU1IiByPSIyIi8+PGNpcmNsZSBjeD0iMzAiIGN5PSIzMCIgcj0iMyIvPjxwYXRoIGQ9Ik01IDVoMjVNNSA1djI1TTU1IDU1SDMwTTU1IDU1VjMwTTMwIDMwSDVNMzAgMzB2MjUiLz48L2c+PC9zdmc+')] opacity-10"></div>
          </div>
        </div>
        <div className="absolute inset-0 flex items-center justify-center px-4 md:px-6">
          <div className="text-center text-white max-w-3xl backdrop-blur-sm bg-black/30 p-8 md:p-10 rounded-xl shadow-[0_0_15px_rgba(0,240,255,0.1)] border border-gray-800">
            <div className="mb-2 flex justify-center">
              <div className="text-cyan-400 text-sm tracking-widest uppercase font-mono">Next Generation</div>
            </div>
            <h1 className="text-4xl md:text-6xl font-extrabold mb-4 tracking-tight bg-clip-text text-transparent bg-gradient-to-r from-cyan-400 via-blue-500 to-emerald-400">
              Summer Collection 2024
            </h1>
            <p className="text-xl md:text-2xl mb-8 font-light leading-relaxed text-gray-300">
              Discover the future of fashion with intelligent designs and smart fabrics
            </p>
            <div className="flex flex-col sm:flex-row gap-5 justify-center">
              <Link href="/products?category=women">
                <Button 
                  size="lg" 
                  className="bg-cyan-900 text-cyan-50 hover:bg-cyan-800 text-lg rounded px-8 py-6 font-medium shadow-lg transform transition hover:shadow-cyan-700/30 hover:shadow-lg border border-cyan-800"
                >
                  Shop Women
                </Button>
              </Link>
              <Link href="/products?category=men">
                <Button 
                  className="bg-gray-900 text-white border border-gray-700 hover:bg-gray-800 hover:border-cyan-700 text-lg rounded px-8 py-6 font-medium shadow-lg transform transition hover:shadow-cyan-700/20" 
                >
                  Shop Men
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </div>
      
      {/* Promo banners */}
      <div className="container mx-auto px-4 py-12 -mt-6">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="bg-gray-900 border border-gray-800 shadow-[0_4px_20px_rgba(0,200,255,0.07)] p-6 rounded-xl flex items-center group hover:shadow-[0_4px_20px_rgba(0,200,255,0.15)] transition-all duration-300 transform hover:-translate-y-1">
            <div className="relative mr-5">
              <div className="absolute inset-0 bg-cyan-500/20 blur-xl rounded-full"></div>
              <div className="relative bg-gray-900 border border-cyan-700 p-3 rounded-full text-cyan-400">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" />
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" d="M15 11a3 3 0 11-6 0 3 3 0 016 0z" />
                </svg>
              </div>
            </div>
            <div>
              <div className="text-xs text-cyan-500 font-mono mb-1 uppercase tracking-wider">Smart Delivery</div>
              <h3 className="font-bold text-lg text-white mb-1 group-hover:text-cyan-400 transition-colors">Free Shipping</h3>
              <p className="text-gray-400">On orders over $50</p>
            </div>
          </div>
          
          <div className="bg-gray-900 border border-gray-800 shadow-[0_4px_20px_rgba(0,200,255,0.07)] p-6 rounded-xl flex items-center group hover:shadow-[0_4px_20px_rgba(0,200,255,0.15)] transition-all duration-300 transform hover:-translate-y-1">
            <div className="relative mr-5">
              <div className="absolute inset-0 bg-blue-500/20 blur-xl rounded-full"></div>
              <div className="relative bg-gray-900 border border-blue-700 p-3 rounded-full text-blue-400">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
                </svg>
              </div>
            </div>
            <div>
              <div className="text-xs text-blue-500 font-mono mb-1 uppercase tracking-wider">Automated System</div>
              <h3 className="font-bold text-lg text-white mb-1 group-hover:text-blue-400 transition-colors">Easy Returns</h3>
              <p className="text-gray-400">30-day hassle-free process</p>
            </div>
          </div>
          
          <div className="bg-gray-900 border border-gray-800 shadow-[0_4px_20px_rgba(0,200,255,0.07)] p-6 rounded-xl flex items-center group hover:shadow-[0_4px_20px_rgba(0,200,255,0.15)] transition-all duration-300 transform hover:-translate-y-1">
            <div className="relative mr-5">
              <div className="absolute inset-0 bg-emerald-500/20 blur-xl rounded-full"></div>
              <div className="relative bg-gray-900 border border-emerald-700 p-3 rounded-full text-emerald-400">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" />
                </svg>
              </div>
            </div>
            <div>
              <div className="text-xs text-emerald-500 font-mono mb-1 uppercase tracking-wider">Quantum Technology</div>
              <h3 className="font-bold text-lg text-white mb-1 group-hover:text-emerald-400 transition-colors">Secure Payment</h3>
              <p className="text-gray-400">End-to-end encryption</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
