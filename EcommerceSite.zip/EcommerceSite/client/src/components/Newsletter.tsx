import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

export default function Newsletter() {
  const [email, setEmail] = useState("");
  const [isSubmitted, setIsSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (email) {
      // In a real app, this would send the email to a backend service
      console.log("Subscribing email:", email);
      setIsSubmitted(true);
      setEmail("");
      
      // Reset submitted state after 3 seconds
      setTimeout(() => {
        setIsSubmitted(false);
      }, 3000);
    }
  };

  return (
    <section className="py-12 bg-gray-100">
      <div className="container mx-auto px-4">
        <div className="max-w-2xl mx-auto text-center">
          <h2 className="text-2xl font-bold mb-3">Subscribe to Our Newsletter</h2>
          <p className="text-gray-600 mb-6">Be the first to know about new arrivals, sales & promos!</p>
          
          {isSubmitted ? (
            <div className="bg-green-100 text-green-700 p-4 rounded-lg mb-6">
              Thank you for subscribing! You'll receive our next newsletter soon.
            </div>
          ) : (
            <form className="flex flex-col sm:flex-row gap-3" onSubmit={handleSubmit}>
              <Input 
                type="email" 
                placeholder="Your email address" 
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
                className="flex-1 border border-gray-300 px-4 py-3 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
              />
              <Button 
                type="submit" 
                className="bg-primary text-white font-medium px-6 py-3 rounded-lg hover:bg-primary/90 transition"
              >
                Subscribe
              </Button>
            </form>
          )}
          
          <p className="text-gray-500 text-sm mt-4">By subscribing you agree to our Terms of Service and Privacy Policy.</p>
        </div>
      </div>
    </section>
  );
}
