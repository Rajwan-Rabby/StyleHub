import { Link } from "wouter";

export default function CategorySection() {
  const categories = [
    {
      id: 1,
      name: "Dresses",
      imageUrl: "https://images.unsplash.com/photo-1541101767792-f9b2b1c4f127?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=80",
      slug: "dresses"
    },
    {
      id: 2,
      name: "Shirts",
      imageUrl: "https://images.unsplash.com/photo-1516257984-b1b4d707412e?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=80",
      slug: "shirts"
    },
    {
      id: 3,
      name: "Shoes",
      imageUrl: "https://images.unsplash.com/photo-1600185365926-3a2ce3cdb9eb?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=80",
      slug: "shoes"
    },
    {
      id: 4,
      name: "Accessories",
      imageUrl: "https://images.unsplash.com/photo-1509695507497-903c140c43b0?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=80",
      slug: "accessories"
    }
  ];

  return (
    <section className="py-12 bg-white">
      <div className="container mx-auto px-4">
        <h2 className="text-2xl font-bold mb-8 text-center">Shop by Category</h2>
        
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {categories.map((category) => (
            <Link key={category.id} href={`/products?category=${category.slug}`} className="group">
                <div className="relative overflow-hidden rounded-lg bg-gray-100 aspect-square">
                  <img 
                    src={category.imageUrl} 
                    alt={category.name} 
                    className="w-full h-full object-cover transition duration-300 group-hover:scale-105"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-gray-900/70 to-transparent flex items-end p-4">
                    <h3 className="text-white font-medium">{category.name}</h3>
                  </div>
                </div>
            </Link>
          ))}
        </div>
      </div>
    </section>
  );
}
