import { Link } from "wouter";
import { useCart } from "@/context/CartContext";
import { Button } from "@/components/ui/button";
import { 
  DropdownMenu, 
  DropdownMenuContent, 
  DropdownMenuItem, 
  DropdownMenuTrigger 
} from "@/components/ui/dropdown-menu";
import { Menu, Search, User, ShoppingBag, ChevronDown } from "lucide-react";

interface HeaderProps {
  onMobileMenuToggle: () => void;
  onSearchToggle: () => void;
  onCartToggle: () => void;
}

export default function Header({ onMobileMenuToggle, onSearchToggle, onCartToggle }: HeaderProps) {
  const { getCartCount } = useCart();
  const cartCount = getCartCount();

  return (
    <header className="bg-white shadow-sm sticky top-0 z-50">
      {/* Top bar with announcement */}
      <div className="bg-primary text-white text-sm py-2">
        <div className="container mx-auto px-4 text-center">
          Free shipping on orders over $50 • Limited time offer: 20% off summer collection
        </div>
      </div>
      
      {/* Main header */}
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between py-4">
          {/* Mobile menu button */}
          <Button 
            variant="ghost" 
            size="icon" 
            className="md:hidden text-gray-500 hover:text-gray-700" 
            onClick={onMobileMenuToggle}
          >
            <Menu className="h-6 w-6" />
          </Button>
          
          {/* Logo */}
          <Link href="/" className="text-primary font-bold text-2xl flex items-center">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 mr-2" viewBox="0 0 20 20" fill="currentColor">
              <path fillRule="evenodd" d="M10 2a8 8 0 100 16 8 8 0 000-16zm0 14a6 6 0 100-12 6 6 0 000 12z" clipRule="evenodd" />
            </svg>
            StyleHub
          </Link>
          
          {/* Desktop navigation */}
          <nav className="hidden md:flex space-x-8 text-sm">
            <Link href="/" className="font-medium text-gray-900 hover:text-primary py-2">
              Home
            </Link>
            
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <button className="font-medium text-gray-900 hover:text-primary py-2 flex items-center">
                  Women
                  <ChevronDown className="h-4 w-4 ml-1" />
                </button>
              </DropdownMenuTrigger>
              <DropdownMenuContent>
                <DropdownMenuItem asChild>
                  <Link href="/products?category=dresses" className="cursor-pointer">
                    Dresses
                  </Link>
                </DropdownMenuItem>
                <DropdownMenuItem asChild>
                  <Link href="/products?category=tops" className="cursor-pointer">
                    Tops
                  </Link>
                </DropdownMenuItem>
                <DropdownMenuItem asChild>
                  <Link href="/products?category=bottoms" className="cursor-pointer">
                    Bottoms
                  </Link>
                </DropdownMenuItem>
                <DropdownMenuItem asChild>
                  <Link href="/products?category=accessories" className="cursor-pointer">
                    Accessories
                  </Link>
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
            
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <button className="font-medium text-gray-900 hover:text-primary py-2 flex items-center">
                  Men
                  <ChevronDown className="h-4 w-4 ml-1" />
                </button>
              </DropdownMenuTrigger>
              <DropdownMenuContent>
                <DropdownMenuItem asChild>
                  <Link href="/products?category=shirts" className="cursor-pointer">
                    Shirts
                  </Link>
                </DropdownMenuItem>
                <DropdownMenuItem asChild>
                  <Link href="/products?category=pants" className="cursor-pointer">
                    Pants
                  </Link>
                </DropdownMenuItem>
                <DropdownMenuItem asChild>
                  <Link href="/products?category=shoes" className="cursor-pointer">
                    Shoes
                  </Link>
                </DropdownMenuItem>
                <DropdownMenuItem asChild>
                  <Link href="/products?category=accessories" className="cursor-pointer">
                    Accessories
                  </Link>
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
            
            <Link href="/products?category=kids" className="font-medium text-gray-900 hover:text-primary py-2">
              Kids
            </Link>
            
            <Link href="/products?category=sale" className="font-medium text-gray-900 hover:text-primary py-2">
              Sale
            </Link>
            
            <Link href="/products?new=true" className="font-medium text-primary py-2">
              New Arrivals
            </Link>
          </nav>
          
          {/* Search, account and cart */}
          <div className="flex items-center space-x-4">
            {/* Search button */}
            <Button
              variant="ghost"
              size="icon"
              className="text-gray-500 hover:text-gray-700"
              onClick={onSearchToggle}
            >
              <Search className="h-5 w-5" />
            </Button>
            
            {/* Account button */}
            <Button
              variant="ghost"
              size="icon"
              className="text-gray-500 hover:text-gray-700"
            >
              <User className="h-5 w-5" />
            </Button>
            
            {/* Cart button */}
            <Button
              variant="ghost"
              size="icon"
              className="text-gray-500 hover:text-gray-700 relative"
              onClick={onCartToggle}
            >
              <ShoppingBag className="h-5 w-5" />
              {cartCount > 0 && (
                <span className="absolute -top-1 -right-1 bg-secondary text-white text-xs w-4 h-4 flex items-center justify-center rounded-full">
                  {cartCount <= 99 ? cartCount : '99+'}
                </span>
              )}
            </Button>
          </div>
        </div>
      </div>
    </header>
  );
}
