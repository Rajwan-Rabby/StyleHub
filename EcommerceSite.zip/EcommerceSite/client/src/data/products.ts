import { Product } from "@/lib/types";

// Mock product data
const products: Product[] = [
  {
    id: 1,
    name: "Striped Linen Blouse",
    description: "A lightweight, breathable linen blouse with vertical stripes. Perfect for casual summer days or dressed up for work.",
    price: 39.99,
    imageUrl: "https://images.unsplash.com/photo-1518622358385-8ea7d0794bf6?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=80",
    category: "tops",
    subcategory: "blouses",
    rating: 4.8,
    reviewCount: 42,
    stockCount: 25,
    isNew: true,
    isFeatured: true,
    isSale: false,
    colors: ["White", "Blue", "Pink"],
    sizes: ["XS", "S", "M", "L", "XL"]
  },
  {
    id: 2,
    name: "Organic Cotton T-shirt",
    description: "An essential wardrobe staple made from 100% organic cotton. Features a classic crew neck and relaxed fit.",
    price: 24.99,
    imageUrl: "https://images.unsplash.com/photo-1603252109303-2751441dd157?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=80",
    category: "tops",
    subcategory: "t-shirts",
    rating: 4.5,
    reviewCount: 18,
    stockCount: 50,
    isNew: true,
    isFeatured: false,
    isSale: false,
    colors: ["White", "Black", "Gray", "Navy"],
    sizes: ["S", "M", "L", "XL"]
  },
  {
    id: 3,
    name: "Classic Denim Jacket",
    description: "A timeless denim jacket with a slightly distressed finish. Perfect for layering in all seasons.",
    price: 79.99,
    salePrice: 59.99,
    imageUrl: "https://images.unsplash.com/photo-1551028719-00167b16eac5?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=80",
    category: "jackets",
    subcategory: "denim",
    rating: 4.9,
    reviewCount: 125,
    stockCount: 15,
    isNew: false,
    isFeatured: true,
    isSale: true,
    colors: ["Blue", "Black"],
    sizes: ["S", "M", "L", "XL"]
  },
  {
    id: 4,
    name: "Urban Sneakers",
    description: "Lightweight, comfortable sneakers with a modern design. Perfect for everyday wear or light exercise.",
    price: 84.99,
    imageUrl: "https://images.unsplash.com/photo-1576995853123-5a10305d93c0?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=80",
    category: "shoes",
    subcategory: "sneakers",
    rating: 4.3,
    reviewCount: 56,
    stockCount: 30,
    isNew: true,
    isFeatured: true,
    isSale: false,
    colors: ["White", "Black", "Gray"],
    sizes: ["39", "40", "41", "42", "43", "44"]
  },
  {
    id: 5,
    name: "Floral Summer Dress",
    description: "A beautiful floral print dress with a flowy silhouette. Perfect for summer parties and special occasions.",
    price: 49.99,
    imageUrl: "https://images.unsplash.com/photo-1551232864-3f0890e580d9?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=80",
    category: "dresses",
    subcategory: "summer",
    rating: 4.7,
    reviewCount: 89,
    stockCount: 20,
    isNew: true,
    isFeatured: true,
    isSale: false,
    colors: ["Blue", "Red", "Yellow"],
    sizes: ["XS", "S", "M", "L"]
  },
  {
    id: 6,
    name: "Casual Linen Shirt",
    description: "A relaxed-fit linen shirt for men, perfect for staying cool and stylish during warm weather.",
    price: 39.99,
    imageUrl: "https://images.unsplash.com/photo-1543076447-215ad9ba6923?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=80",
    category: "shirts",
    subcategory: "casual",
    rating: 4.6,
    reviewCount: 35,
    stockCount: 40,
    isNew: false,
    isFeatured: true,
    isSale: false,
    colors: ["White", "Beige", "Light Blue"],
    sizes: ["S", "M", "L", "XL", "XXL"]
  },
  {
    id: 7,
    name: "Classic Leather Belt",
    description: "A high-quality leather belt with a minimalist design and durable metal buckle.",
    price: 29.99,
    salePrice: 24.99,
    imageUrl: "https://images.unsplash.com/photo-1552301726-005f8c394f8f?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=80",
    category: "accessories",
    subcategory: "belts",
    rating: 4.8,
    reviewCount: 48,
    stockCount: 35,
    isNew: false,
    isFeatured: false,
    isSale: true,
    colors: ["Brown", "Black"],
    sizes: ["S", "M", "L"]
  },
  {
    id: 8,
    name: "Slim Fit Chino Pants",
    description: "Modern slim-fit chino pants with a comfortable stretch fabric. Perfect for both casual and smart-casual looks.",
    price: 45.99,
    imageUrl: "https://images.unsplash.com/photo-1541099649105-f69ad21f3246?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=80",
    category: "pants",
    subcategory: "chinos",
    rating: 4.4,
    reviewCount: 62,
    stockCount: 28,
    isNew: true,
    isFeatured: false,
    isSale: false,
    colors: ["Khaki", "Navy", "Olive", "Black"],
    sizes: ["28", "30", "32", "34", "36"]
  },
  {
    id: 9,
    name: "Oversized Knit Sweater",
    description: "A cozy oversized sweater made from a soft wool blend. Perfect for staying warm during colder months.",
    price: 59.99,
    salePrice: 44.99,
    imageUrl: "https://images.unsplash.com/photo-1576871337632-b9aef4c17ab9?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=80",
    category: "tops",
    subcategory: "sweaters",
    rating: 4.5,
    reviewCount: 75,
    stockCount: 15,
    isNew: false,
    isFeatured: true,
    isSale: true,
    colors: ["Cream", "Gray", "Burgundy"],
    sizes: ["S", "M", "L"]
  },
  {
    id: 10,
    name: "Leather Crossbody Bag",
    description: "A stylish and practical leather crossbody bag with multiple compartments for all your essentials.",
    price: 89.99,
    imageUrl: "https://images.unsplash.com/photo-1584917865442-de89df76afd3?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=80",
    category: "accessories",
    subcategory: "bags",
    rating: 4.9,
    reviewCount: 104,
    stockCount: 12,
    isNew: true,
    isFeatured: true,
    isSale: false,
    colors: ["Brown", "Black", "Tan"],
    sizes: []
  },
  {
    id: 11,
    name: "High-Waisted Jeans",
    description: "Flattering high-waisted jeans with a slight stretch for maximum comfort. Features a classic five-pocket design.",
    price: 54.99,
    imageUrl: "https://images.unsplash.com/photo-1541099649105-f69ad21f3246?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=80",
    category: "bottoms",
    subcategory: "jeans",
    rating: 4.6,
    reviewCount: 87,
    stockCount: 30,
    isNew: false,
    isFeatured: false,
    isSale: false,
    colors: ["Blue", "Black", "Light Wash"],
    sizes: ["24", "26", "28", "30", "32"]
  },
  {
    id: 12,
    name: "Athletic Performance Shorts",
    description: "Lightweight, quick-drying athletic shorts with built-in compression liner. Perfect for workouts and running.",
    price: 34.99,
    salePrice: 29.99,
    imageUrl: "https://images.unsplash.com/photo-1560769680-ba2f3767c785?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=80",
    category: "bottoms",
    subcategory: "shorts",
    rating: 4.7,
    reviewCount: 65,
    stockCount: 45,
    isNew: false,
    isFeatured: false,
    isSale: true,
    colors: ["Black", "Gray", "Navy"],
    sizes: ["S", "M", "L", "XL"]
  },
  {
    id: 13,
    name: "Casual Canvas Slip-ons",
    description: "Comfortable canvas slip-on shoes perfect for casual everyday wear. Features a cushioned insole and durable outsole.",
    price: 29.99,
    imageUrl: "https://images.unsplash.com/photo-1595950653106-6c9ebd614d3a?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=80",
    category: "shoes",
    subcategory: "casual",
    rating: 4.3,
    reviewCount: 42,
    stockCount: 38,
    isNew: true,
    isFeatured: false,
    isSale: false,
    colors: ["White", "Black", "Navy", "Red"],
    sizes: ["38", "39", "40", "41", "42", "43", "44"]
  },
  {
    id: 14,
    name: "Vintage-Inspired Sunglasses",
    description: "Retro-style sunglasses with UV protection and a classic design that suits most face shapes.",
    price: 24.99,
    imageUrl: "https://images.unsplash.com/photo-1511499767150-a48a237f0083?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=80",
    category: "accessories",
    subcategory: "sunglasses",
    rating: 4.5,
    reviewCount: 31,
    stockCount: 25,
    isNew: false,
    isFeatured: true,
    isSale: false,
    colors: ["Black", "Tortoise", "Clear"],
    sizes: []
  },
  {
    id: 15,
    name: "Formal Blazer",
    description: "A tailored blazer with a modern fit, perfect for formal occasions or to elevate any casual outfit.",
    price: 99.99,
    salePrice: 79.99,
    imageUrl: "https://images.unsplash.com/photo-1603251579711-8129ee4cd060?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=80",
    category: "jackets",
    subcategory: "blazers",
    rating: 4.8,
    reviewCount: 53,
    stockCount: 18,
    isNew: false,
    isFeatured: false,
    isSale: true,
    colors: ["Black", "Navy", "Gray"],
    sizes: ["36", "38", "40", "42", "44"]
  },
  {
    id: 16,
    name: "Pleated Midi Skirt",
    description: "An elegant pleated midi skirt with an elastic waistband for comfort. Perfect for both casual and dressy occasions.",
    price: 44.99,
    imageUrl: "https://images.unsplash.com/photo-1583496661160-fb5886a0aaaa?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=80",
    category: "bottoms",
    subcategory: "skirts",
    rating: 4.7,
    reviewCount: 29,
    stockCount: 22,
    isNew: true,
    isFeatured: true,
    isSale: false,
    colors: ["Black", "Beige", "Pink"],
    sizes: ["XS", "S", "M", "L"]
  }
];

// Get all products
export const getProducts = async (): Promise<Product[]> => {
  // Simulate API delay
  await new Promise(resolve => setTimeout(resolve, 500));
  return products;
};

// Get product by ID
export const getProductById = async (id: number): Promise<Product> => {
  // Simulate API delay
  await new Promise(resolve => setTimeout(resolve, 500));
  
  const product = products.find(p => p.id === id);
  if (!product) {
    throw new Error(`Product with ID ${id} not found`);
  }
  
  return product;
};

// Get featured products
export const getFeaturedProducts = async (): Promise<Product[]> => {
  // Simulate API delay
  await new Promise(resolve => setTimeout(resolve, 500));
  
  return products.filter(p => p.isFeatured);
};

// Get new arrival products
export const getNewArrivals = async (): Promise<Product[]> => {
  // Simulate API delay
  await new Promise(resolve => setTimeout(resolve, 500));
  
  return products.filter(p => p.isNew);
};

// Get sale products
export const getSaleProducts = async (): Promise<Product[]> => {
  // Simulate API delay
  await new Promise(resolve => setTimeout(resolve, 500));
  
  return products.filter(p => p.isSale);
};

// Get products by category
export const getProductsByCategory = async (category: string): Promise<Product[]> => {
  // Simulate API delay
  await new Promise(resolve => setTimeout(resolve, 500));
  
  return products.filter(p => p.category === category);
};

// Search products
export const searchProducts = async (query: string): Promise<Product[]> => {
  // Simulate API delay
  await new Promise(resolve => setTimeout(resolve, 500));
  
  const lowerCaseQuery = query.toLowerCase();
  return products.filter(p => 
    p.name.toLowerCase().includes(lowerCaseQuery) || 
    p.description.toLowerCase().includes(lowerCaseQuery) ||
    p.category.toLowerCase().includes(lowerCaseQuery)
  );
};
