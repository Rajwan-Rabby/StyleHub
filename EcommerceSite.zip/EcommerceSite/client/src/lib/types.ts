export interface Product {
  id: number;
  name: string;
  description: string;
  price: number;
  salePrice?: number;
  imageUrl: string;
  category: string;
  subcategory?: string;
  rating: number;
  reviewCount: number;
  stockCount: number;
  isNew: boolean;
  isFeatured: boolean;
  isSale: boolean;
  colors: string[];
  sizes: string[];
}

export interface Category {
  id: number;
  name: string;
  imageUrl: string;
  slug: string;
}

export interface PromoItem {
  id: number;
  title: string;
  description: string;
  imageUrl: string;
  buttonText: string;
  buttonLink: string;
  bgColor: string;
}

export interface FilterOptions {
  categories: string[];
  priceRange: [number, number];
  rating: number | null;
  onSale: boolean;
}

export interface SortOption {
  id: string;
  name: string;
}

export interface CheckoutFormData {
  fullName: string;
  email: string;
  address: string;
  city: string;
  state: string;
  zipCode: string;
  country: string;
  cardNumber: string;
  cardExpiry: string;
  cardCvc: string;
}
