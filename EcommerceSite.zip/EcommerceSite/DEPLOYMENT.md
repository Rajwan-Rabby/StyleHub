# Deployment Guide for StyleHub E-commerce

This guide will help you deploy the StyleHub e-commerce platform to various hosting services.

## Prerequisites

- NodeJS v18 or higher
- PostgreSQL database
- Git

## Preparing for Deployment

1. Run the deployment script to package your application:
   ```bash
   ./deploy.sh
   ```

2. This will create a `deployment` folder with all necessary files.

## Deployment Options

### Option 1: GitHub Pages + External Backend Hosting

1. Push your code to GitHub:
   ```bash
   cd deployment
   git init
   git add .
   git commit -m "Initial deployment"
   git remote add origin https://github.com/yourusername/stylehub-ecommerce.git
   git push -u origin main
   ```

2. Host the backend on a service like:
   - Heroku
   - Railway
   - DigitalOcean
   - Render
   - Vercel

### Option 2: Heroku Deployment

1. Install Heroku CLI:
   ```bash
   npm install -g heroku
   ```

2. Login to Heroku:
   ```bash
   heroku login
   ```

3. Create a new Heroku app:
   ```bash
   cd deployment
   heroku create stylehub-ecommerce
   ```

4. Add PostgreSQL:
   ```bash
   heroku addons:create heroku-postgresql:hobby-dev
   ```

5. Deploy to Heroku:
   ```bash
   git push heroku main
   ```

6. Run database migrations:
   ```bash
   heroku run npm run db:push
   ```

7. Seed the database:
   ```bash
   heroku run curl $(heroku info -s | grep web_url | cut -d= -f2)/api/seed
   ```

### Option 3: Vercel Deployment

1. Install Vercel CLI:
   ```bash
   npm install -g vercel
   ```

2. Login to Vercel:
   ```bash
   vercel login
   ```

3. Deploy the application:
   ```bash
   cd deployment
   vercel
   ```

4. Connect your database in Vercel dashboard or use a separate PostgreSQL provider.

## Environment Variables

Make sure to set these environment variables on your hosting platform:

- `DATABASE_URL`: Your PostgreSQL connection string
- `STRIPE_SECRET_KEY` (optional): For payment processing
- `VITE_STRIPE_PUBLIC_KEY` (optional): For payment processing client-side

## Post-Deployment Steps

1. Verify that the database schema has been properly created
2. Seed the database with initial products using the `/api/seed` endpoint
3. Test the application thoroughly to ensure everything is working

## Troubleshooting

- **Database connection issues**: Check that your `DATABASE_URL` is correctly formatted and accessible from your hosting provider
- **Build failures**: Ensure Node.js version is at least v18
- **Static asset issues**: Check that vite is properly building your frontend assets

For additional help, refer to the documentation of your chosen hosting platform.