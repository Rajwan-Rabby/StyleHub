#!/bin/bash

# Build script for production deployment

echo "Building project for deployment..."

# Build frontend and backend
npm run build

# Create a deployment folder
mkdir -p deployment

# Copy necessary files for deployment
cp -r dist deployment/
cp package.json deployment/
cp package-lock.json deployment/
cp Procfile deployment/
cp .env.example deployment/
cp README.md deployment/
cp drizzle.config.ts deployment/

echo "Project built and ready for deployment in the 'deployment' folder"
echo "Make sure to set up your environment variables before deploying"
echo "You can upload this folder to your GitHub repository or deploy directly to hosting platforms"