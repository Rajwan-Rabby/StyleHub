# StyleHub E-commerce Platform

A fully functional e-commerce website built with React, TypeScript, and PostgreSQL. StyleHub offers a modern shopping experience with a clean, responsive design and seamless user flow from browsing to checkout.

![StyleHub Screenshot](./client/public/screenshot.png)

## Features

- **Responsive Design**: Optimized for mobile, tablet, and desktop viewports
- **Product Catalog**: Browse by category, filter options, and advanced search
- **Shopping Cart**: Add/remove items, adjust quantities with persistent state
- **User Authentication**: Secure login, registration and profile management
- **Checkout Flow**: Multi-step checkout with shipping and payment options
- **Payment Processing**: Stripe integration for secure payments
- **Database Integration**: PostgreSQL with robust data schema
- **Dark/Light Mode**: Toggle between themes for better accessibility
- **Responsive UI**: Built with shadcn/ui components for a cohesive design system

## Tech Stack

### Frontend
- **Framework**: React 18 with TypeScript
- **Styling**: TailwindCSS with shadcn/ui components
- **State Management**: React Context API & TanStack Query
- **Routing**: wouter for lightweight navigation
- **Form Handling**: react-hook-form with zod validation

### Backend
- **Server**: Express.js on Node.js
- **Database**: PostgreSQL with Drizzle ORM
- **Authentication**: Passport.js with session management
- **API**: RESTful endpoints with proper error handling
- **Payment Processing**: Stripe API integration

## Getting Started

### Prerequisites

- Node.js (v18+)
- npm or yarn
- PostgreSQL database
- [Optional] Stripe account for payment processing

### Installation

1. Clone the repository
```bash
git clone https://github.com/yourusername/stylehub-ecommerce.git
cd stylehub-ecommerce
```

2. Install dependencies
```bash
npm install
```

3. Set up environment variables
Create a `.env` file in the root directory with the following variables:
```
# Required
DATABASE_URL=postgresql://username:password@localhost:5432/stylehub

# Optional - for Stripe payment processing
STRIPE_SECRET_KEY=sk_test_your_stripe_secret_key
VITE_STRIPE_PUBLIC_KEY=pk_test_your_stripe_public_key
```

4. Push the database schema
```bash
npm run db:push
```

5. Seed the database with sample products
```bash
# Start the server first
npm run dev

# Then in another terminal, seed the database
curl http://localhost:5000/api/seed
```

6. Start the development server
```bash
npm run dev
```

7. Open your browser and navigate to `http://localhost:5000`

## Project Structure

```
stylehub-ecommerce/
├── client/                   # Frontend React application
│   ├── src/
│   │   ├── components/       # Reusable UI components
│   │   ├── context/          # React context providers
│   │   ├── data/             # Mock data and API calls
│   │   ├── hooks/            # Custom React hooks
│   │   ├── lib/              # Utility functions
│   │   ├── pages/            # Page components
│   │   └── App.tsx           # Main application component
├── server/                   # Backend Express application
│   ├── routes.ts             # API routes
│   ├── storage.ts            # Database operations
│   ├── db.ts                 # Database connection
│   └── index.ts              # Server entry point
├── shared/                   # Shared code between client and server
│   └── schema.ts             # Database schema and types
└── [configuration files]     # Various config files
```

## Development

### Adding New Products

To add new products, you can either:

1. Modify the seed data in `server/routes.ts`
2. Use the API directly:
```bash
curl -X POST http://localhost:5000/api/products \
  -H "Content-Type: application/json" \
  -d '{"name":"New Product","price":99.99,"description":"Product description",...}'
```

### Database Migrations

When changing the database schema:
1. Update the models in `shared/schema.ts`
2. Run `npm run db:push` to update the database schema

## Deployment

For detailed deployment instructions, see [DEPLOYMENT.md](./DEPLOYMENT.md). You can deploy this application to:

- Vercel
- Heroku
- Netlify
- DigitalOcean
- AWS
- Any other Node.js hosting platform

Make sure to set up the PostgreSQL database and environment variables on your hosting platform.

## Contributions

Contributions are welcome! Please feel free to submit a Pull Request.

## License

This project is licensed under the MIT License - see the LICENSE file for details.
